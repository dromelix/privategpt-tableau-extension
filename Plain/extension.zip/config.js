// window.API_URL = 'http://localhost:8080/privategpt'
window.API_URL = 'http://localhost:8001'

SYSTEM_PROMPT = `Answer to user's questions in English(no Chinese).
Don't provide any extra prompt examples, only return answer for user's questions.`
